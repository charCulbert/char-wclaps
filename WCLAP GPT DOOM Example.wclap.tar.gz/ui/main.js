// DOOM inside the WCLAP WebView interface.
//
// doomgeneric exposes its framebuffer, key queue, and a thin checkpoint bridge.
// Native DOOM save files are periodically copied to the WCLAP core, where
// clap.state can retain them after this WebView is destroyed.

const status = document.querySelector("#status");
const canvas = document.querySelector("#screen");
const ctx = canvas.getContext("2d");

const Commands = Object.freeze({ready: 1, closed: 2, checkpoint: 4, restoreCheckpoint: 5});
const checkpointInterval = 4000;
const checkpointChunkHeaderSize = 13;
const checkpointChunkPayloadSize = 8 * 1024;
const maximumCheckpointSize = 1024 * 1024;
let doom = null;
let pendingRestore = null;
let incomingRestore = null;
let checkpointTransferId = 0;
let checkpointTimer = 0;
let checkpointBlockedUntil = 0;

const send = bytes => parent.postMessage(bytes, "*");
const controlHelp = "Click the screen, then play. WASD move, Ctrl/F fire, Space use.";

// event.code -> doomkeys.h key codes.
const keyByCode = {
	ArrowLeft: 0xac,
	ArrowRight: 0xae,
	ArrowUp: 0xad,
	ArrowDown: 0xaf,
	KeyW: 0xad,
	KeyS: 0xaf,
	KeyA: 0xa0,
	KeyD: 0xa1,
	ShiftLeft: 0x80 + 0x36,
	ShiftRight: 0x80 + 0x36,
	ControlLeft: 0xa3,
	ControlRight: 0xa3,
	KeyF: 0xa3,
	Space: 0xa2,
	Enter: 13,
	NumpadEnter: 13,
	Escape: 27,
	Tab: 9,
	Backspace: 127,
	Equal: 0x3d,
	Minus: 0x2d,
	Digit1: 49,
	Digit2: 50,
	Digit3: 51,
	Digit4: 52,
	Digit5: 53,
	Digit6: 54,
	Digit7: 55,
};

function doomKeyFor(event) {
	if (keyByCode[event.code] !== undefined) return keyByCode[event.code];
	return event.key.length === 1 ? event.key.toLowerCase().charCodeAt(0) : undefined;
}

function messageBytes(value) {
	if (value instanceof ArrayBuffer) return new Uint8Array(value);
	if (ArrayBuffer.isView(value))
		return new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
	return null;
}

function showTemporaryStatus(message) {
	status.textContent = message;
	setTimeout(() => {
		if (status.textContent === message) status.textContent = controlHelp;
	}, 1200);
}

function restoreCheckpoint(bytes) {
	if (!doom || !bytes?.length) return false;
	const pointer = doom._malloc(bytes.length);
	if (!pointer) return false;
	let restored = false;
	try {
		doom.HEAPU8.set(bytes, pointer);
		restored = Boolean(doom._DG_LoadCheckpoint(pointer, bytes.length));
	} finally {
		doom._free(pointer);
	}
	if (restored) {
		document.body.dataset.checkpointRestored = "true";
		checkpointBlockedUntil = performance.now() + checkpointInterval;
		showTemporaryStatus("Restoring saved game…");
	}
	return restored;
}

function sendCheckpointChunks(bytes) {
	checkpointTransferId = (checkpointTransferId + 1) >>> 0;
	if (checkpointTransferId === 0) checkpointTransferId = 1;
	for (let offset = 0; offset < bytes.length; offset += checkpointChunkPayloadSize) {
		const payloadSize = Math.min(checkpointChunkPayloadSize, bytes.length - offset);
		const message = new Uint8Array(checkpointChunkHeaderSize + payloadSize);
		const header = new DataView(message.buffer);
		message[0] = Commands.checkpoint;
		header.setUint32(1, checkpointTransferId, true);
		header.setUint32(5, bytes.length, true);
		header.setUint32(9, offset, true);
		message.set(bytes.subarray(offset, offset + payloadSize), checkpointChunkHeaderSize);
		send(message);
	}
}

function captureCheckpoint() {
	if (!doom || performance.now() < checkpointBlockedUntil) return false;
	const size = doom._DG_CreateCheckpoint();
	if (!Number.isInteger(size) || size <= 0 || size > maximumCheckpointSize) return false;
	const pointer = doom._malloc(size);
	if (!pointer) return false;
	try {
		if (doom._DG_ReadCheckpoint(pointer, size) !== size) return false;
		sendCheckpointChunks(new Uint8Array(doom.HEAPU8.buffer, pointer, size));
		return true;
	} finally {
		doom._free(pointer);
	}
}

function receiveRestoreChunk(bytes) {
	if (bytes.length <= checkpointChunkHeaderSize) return;
	const header = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	const transferId = header.getUint32(1, true);
	const totalSize = header.getUint32(5, true);
	const offset = header.getUint32(9, true);
	const payloadSize = bytes.length - checkpointChunkHeaderSize;
	if (transferId === 0 || totalSize === 0 || totalSize > maximumCheckpointSize
		|| payloadSize > checkpointChunkPayloadSize || offset > totalSize
		|| payloadSize > totalSize - offset) return;

	if (offset === 0) {
		try {
			incomingRestore = {transferId, totalSize, received: 0,
				bytes: new Uint8Array(totalSize)};
		} catch {
			incomingRestore = null;
			return;
		}
	}
	if (!incomingRestore || incomingRestore.transferId !== transferId
		|| incomingRestore.totalSize !== totalSize || incomingRestore.received !== offset) {
		incomingRestore = null;
		return;
	}
	incomingRestore.bytes.set(bytes.subarray(checkpointChunkHeaderSize), offset);
	incomingRestore.received += payloadSize;
	if (incomingRestore.received !== totalSize) return;
	pendingRestore = incomingRestore.bytes;
	incomingRestore = null;
	if (restoreCheckpoint(pendingRestore)) pendingRestore = null;
}

addEventListener("message", event => {
	const bytes = messageBytes(event.data);
	if (!bytes || bytes[0] !== Commands.restoreCheckpoint) return;
	receiveRestoreChunk(bytes);
});

async function start() {
	status.textContent = "Loading DOOM shareware WAD…";
	const wadResponse = await fetch("doom1.wad");
	if (!wadResponse.ok) throw new Error(`Could not load doom1.wad (${wadResponse.status})`);
	const wad = new Uint8Array(await wadResponse.arrayBuffer());

	status.textContent = "Starting DOOM…";
	doom = await createDoomModule({
		locateFile: path => (path.endsWith(".wasm") ? "doom.wasm" : path),
		preRun: [module => module.FS.writeFile("/doom1.wad", wad)],
	});

	const args = ["doomgeneric", "-iwad", "/doom1.wad"];
	const argPointers = args.map(argument => {
		const pointer = doom._malloc(argument.length + 1);
		for (let index = 0; index < argument.length; ++index)
			doom.setValue(pointer + index, argument.charCodeAt(index), "i8");
		doom.setValue(pointer + argument.length, 0, "i8");
		return pointer;
	});
	const argvPointer = doom._malloc(argPointers.length * 4);
	argPointers.forEach((pointer, index) => doom.setValue(argvPointer + index * 4, pointer, "i32"));
	doom._doomgeneric_Create(args.length, argvPointer);
	argPointers.forEach(pointer => doom._free(pointer));
	doom._free(argvPointer);

	if (pendingRestore && restoreCheckpoint(pendingRestore)) pendingRestore = null;

	const width = doom._DG_GetScreenWidth();
	const height = doom._DG_GetScreenHeight();
	canvas.width = width;
	canvas.height = height;
	const framePointer = doom._DG_GetFrameBuffer();
	const image = ctx.createImageData(width, height);
	const output = new Uint32Array(image.data.buffer);

	const pushKey = (pressed, key) => doom._DG_PushKeyEvent(pressed ? 1 : 0, key);
	addEventListener("keydown", event => {
		const key = doomKeyFor(event);
		if (key === undefined) return;
		event.preventDefault();
		pushKey(1, key);
	});
	addEventListener("keyup", event => {
		const key = doomKeyFor(event);
		if (key === undefined) return;
		event.preventDefault();
		pushKey(0, key);
	});
	canvas.addEventListener("pointerdown", () => canvas.focus());
	canvas.focus();

	// doomgeneric_Tick always advances at least one game tic, so throttle it to
	// DOOM's native 35 Hz rather than the browser's usual 60 Hz paint rate.
	const tickInterval = 1000 / 35;
	let lastTick = 0;
	const frame = now => {
		requestAnimationFrame(frame);
		if (now - lastTick < tickInterval) return;
		lastTick = now - ((now - lastTick) % tickInterval);
		doom._doomgeneric_Tick();
		const input = new Uint32Array(doom.HEAPU8.buffer, framePointer, width * height);
		for (let index = 0; index < output.length; ++index) {
			const pixel = input[index];
			output[index] = (0xFF000000 | ((pixel << 16) & 0xFF0000) | (pixel & 0xFF00)
				| ((pixel >>> 16) & 0xFF)) >>> 0;
		}
		ctx.putImageData(image, 0, 0);
	};
	requestAnimationFrame(frame);

	status.textContent = controlHelp;
	send(new Uint8Array([Commands.ready]));
	checkpointTimer = setInterval(captureCheckpoint, checkpointInterval);
}

addEventListener("pagehide", () => {
	clearInterval(checkpointTimer);
	captureCheckpoint();
	send(new Uint8Array([Commands.closed]));
});

start().catch(error => {
	status.textContent = `Failed to start DOOM: ${error}`;
});
