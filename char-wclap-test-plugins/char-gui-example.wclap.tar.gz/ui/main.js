const status = document.querySelector("#status");
const send = command => parent.postMessage(new Uint8Array([command]), "*");

document.addEventListener("click", event => {
	if (event.target.dataset.command) send(Number(event.target.dataset.command));
});

addEventListener("message", event => {
	const bytes = new Uint8Array(event.data);
	if (bytes.length > 1) {
		status.textContent = bytes[1] ? "Host accepted." : "Host rejected.";
		if (bytes[0] === 1) send(8);
	}
	else if (bytes.length) send(bytes[0]);
});

requestAnimationFrame(async () => {
	const styled = getComputedStyle(document.body)
		.getPropertyValue("--wclap-resources").trim() === "ready";
	const message = await fetch("message.txt?v=1").then(response => response.text());
	if (styled && message.trim() === "Multi-file resources ready.") send(1);
});
